import 'dart:async';
import 'dart:math' as math;

import 'package:geolocator/geolocator.dart' as geo;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart' as mb;
import 'package:material_ui/material_ui.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'app_theme.dart';
import 'config.dart';
import 'geo_utils.dart';
import 'instructions_ms.dart';
import 'mapbox_api.dart';
import 'models.dart';
import 'voice.dart';
import 'widgets.dart';

// Had untuk logik navigasi (meter / saat).
const double _arrivedMeters = 30;
const double _offRouteMeters = 50;
const int _offRouteHits = 3;
const Duration _rerouteCooldown = Duration(seconds: 15);

/// Pilihan tema: ikut waktu, sentiasa siang, sentiasa malam.
enum ThemePref { auto, day, night }

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({super.key});

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  final MapboxApi _api = MapboxApi(kMapboxToken);
  final VoiceGuide _voice = VoiceGuide();

  // Peta
  mb.MapboxMap? _map;
  mb.PolylineAnnotationManager? _lineManager;
  mb.CircleAnnotationManager? _markerManager;
  mb.CircleAnnotationManager? _fuelManager;

  // Tema
  ThemePref _themePref = ThemePref.auto;
  late bool _night;
  late final String _initialStyle;
  late String _currentStyle;
  Timer? _themeTimer;

  // Susun atur (dikemas kini dalam build)
  bool _landscape = false;
  double _panelWidth = 0;
  Size _screen = Size.zero;

  // Carian
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();
  Timer? _debounce;
  List<PlaceResult> _results = [];
  bool _searching = false;
  String? _searchMessage;

  // Lokasi
  LatLng? _myPos;
  double? _heading;
  double _speedKmh = 0;
  double _accuracy = 10;
  bool _locationReady = false;
  StreamSubscription<geo.Position>? _posSub;

  // Laluan & navigasi
  PlaceResult? _destination;
  PlaceResult? _stop;
  NavRoute? _route;
  List<PlaceResult> _fuelResults = [];
  bool _loadingRoute = false;
  bool _navigating = false;
  bool _arrived = false;
  bool _followUser = true;
  int _stepIndex = 0;
  int _snapSegment = 0;
  double _distToManeuver = 0;
  double _remainingDistance = 0;
  double _remainingDuration = 0;
  double? _limitKmh;
  RouteIncident? _incidentAhead;
  double _incidentDist = 0;
  int _offRouteCount = 0;
  DateTime _lastReroute = DateTime.fromMillisecondsSinceEpoch(0);

  // Suara
  bool _voiceOn = true;
  int _announcedStep = -1;
  bool _saidFar = false;
  bool _saidNear = false;
  final Set<int> _announcedIncidents = {};
  String? _speechPrefix;

  @override
  void initState() {
    super.initState();
    _night = _computeNight(); // sama dengan nilai awal nightMode
    _initialStyle = _night ? kStyleNight : kStyleDay;
    _currentStyle = _initialStyle;
    _themeTimer =
        Timer.periodic(const Duration(minutes: 1), (_) => _applyTheme());
    _initVoice();
    _keepScreenOn();
    _initLocation();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _themeTimer?.cancel();
    _posSub?.cancel();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    _voice.stop();
    WakelockPlus.disable().catchError((_) {});
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // Skrin, suara & tema
  // ---------------------------------------------------------------------

  /// Skrin kekal menyala selagi aplikasi dibuka (seperti Waze).
  Future<void> _keepScreenOn() async {
    try {
      await WakelockPlus.enable();
    } catch (_) {}
  }

  Future<void> _initVoice() async {
    await _voice.init();
    if (!mounted) return;
    if (_voice.language == null) {
      _toast('Suara tidak tersedia. Semak tetapan "Text-to-speech" telefon.');
    } else if (!_voice.usingMalay) {
      _toast('Suara Bahasa Melayu tiada di telefon — guna suara Indonesia.');
    }
  }

  void _say(String text) {
    final prefix = _speechPrefix;
    _speechPrefix = null;
    _voice.speak(prefix == null ? text : '$prefix $text');
  }

  bool _computeNight() {
    switch (_themePref) {
      case ThemePref.day:
        return false;
      case ThemePref.night:
        return true;
      case ThemePref.auto:
        return isNightHour();
    }
  }

  Future<void> _applyTheme() async {
    final night = _computeNight();
    if (night != _night && mounted) setState(() => _night = night);
    nightMode.value = night;
    final uri = night ? kStyleNight : kStyleDay;
    if (uri == _currentStyle) return;
    _currentStyle = uri;
    try {
      await _map?.style.setStyleURI(uri);
    } catch (_) {}
    // Warna laluan berbeza ikut tema.
    final route = _route;
    if (route != null) await _drawRoute(route);
  }

  void _cycleTheme() {
    final next = ThemePref.values[(_themePref.index + 1) % 3];
    setState(() => _themePref = next);
    _toast(switch (next) {
      ThemePref.auto => 'Tema: Auto (siang 7 pagi – 7 malam)',
      ThemePref.day => 'Tema: Siang',
      ThemePref.night => 'Tema: Malam',
    });
    _applyTheme();
  }

  // ---------------------------------------------------------------------
  // Lokasi
  // ---------------------------------------------------------------------

  Future<void> _initLocation() async {
    try {
      final serviceOn = await geo.Geolocator.isLocationServiceEnabled();
      if (!serviceOn) {
        _toast('Sila hidupkan GPS / Lokasi di telefon anda.');
        return;
      }
      var perm = await geo.Geolocator.checkPermission();
      if (perm == geo.LocationPermission.denied) {
        perm = await geo.Geolocator.requestPermission();
      }
      if (perm == geo.LocationPermission.denied ||
          perm == geo.LocationPermission.deniedForever) {
        _toast('Kebenaran lokasi diperlukan untuk navigasi.');
        return;
      }

      if (!mounted) return;
      setState(() => _locationReady = true);
      await _enablePuck();

      try {
        final p = await geo.Geolocator.getCurrentPosition(
          locationSettings: const geo.LocationSettings(
            accuracy: geo.LocationAccuracy.high,
            timeLimit: Duration(seconds: 15),
          ),
        );
        _onPosition(p);
        await _flyTo(_myPos!, zoom: 15);
      } catch (_) {
        // Abaikan — strim di bawah akan beri lokasi nanti.
      }

      _posSub = geo.Geolocator.getPositionStream(
        locationSettings: const geo.LocationSettings(
          accuracy: geo.LocationAccuracy.bestForNavigation,
          distanceFilter: 5,
        ),
      ).listen(_onPosition, onError: (Object _) {});
    } catch (_) {
      _toast('Gagal mendapatkan lokasi.');
    }
  }

  Future<void> _enablePuck() async {
    final map = _map;
    if (map == null || !_locationReady) return;
    try {
      await map.location.updateSettings(mb.LocationComponentSettings(
        enabled: true,
        pulsingEnabled: true,
        puckBearingEnabled: true,
      ));
    } catch (_) {}
  }

  void _onPosition(geo.Position p) {
    final hadPos = _myPos != null;
    _myPos = LatLng(p.latitude, p.longitude);
    _speedKmh = math.max(0.0, p.speed * 3.6);
    _accuracy = p.accuracy;
    if (p.heading >= 0 && p.speed > 1.5) _heading = p.heading;

    if (_navigating && _route != null) {
      _updateProgress();
      if (_followUser) _followCamera();
    }

    // Jika destinasi dipilih sebelum GPS sedia, kira laluan sekarang.
    if (!hadPos && _destination != null && _route == null && !_loadingRoute) {
      _loadRoute();
    }

    if (mounted) setState(() {});
  }

  // ---------------------------------------------------------------------
  // Peta & kamera
  // ---------------------------------------------------------------------

  Future<void> _onMapCreated(mb.MapboxMap map) async {
    _map = map;
    try {
      _lineManager = await map.annotations.createPolylineAnnotationManager();
      _fuelManager = await map.annotations.createCircleAnnotationManager();
      _markerManager = await map.annotations.createCircleAnnotationManager();
    } catch (_) {}
    await _enablePuck();
    final pos = _myPos;
    if (pos != null) await _flyTo(pos, zoom: 15);
  }

  /// Dipanggil setiap kali gaya peta siap dimuatkan (termasuk tukar tema).
  Future<void> _onStyleLoaded() async {
    await _enablePuck();
    final route = _route;
    if (route != null) await _drawRoute(route);
    await _drawMarkers();
    await _drawFuelMarkers();
  }

  mb.Point _pt(LatLng p) => mb.Point(coordinates: mb.Position(p.lng, p.lat));

  Future<void> _flyTo(LatLng p, {double zoom = 15}) async {
    final map = _map;
    if (map == null) return;
    try {
      await map.flyTo(
        mb.CameraOptions(
          center: _pt(p),
          zoom: zoom,
          pitch: 0,
          bearing: 0,
          padding: _sidePadding(),
        ),
        mb.MapAnimationOptions(duration: 1000),
      );
    } catch (_) {}
  }

  /// Ruang yang dilindungi panel (landscape: panel di kiri).
  mb.MbxEdgeInsets _sidePadding() => _landscape
      ? mb.MbxEdgeInsets(top: 0, left: _panelWidth, bottom: 0, right: 0)
      : mb.MbxEdgeInsets(top: 0, left: 0, bottom: 0, right: 0);

  Future<void> _followCamera() async {
    final map = _map;
    final pos = _myPos;
    if (map == null || pos == null) return;
    // Letak titik pengguna di bahagian bawah supaya nampak jalan di hadapan.
    final padding = _landscape
        ? mb.MbxEdgeInsets(
            top: _screen.height * 0.35,
            left: _panelWidth,
            bottom: 0,
            right: 0)
        : mb.MbxEdgeInsets(
            top: _screen.height * 0.40, left: 0, bottom: 0, right: 0);
    try {
      await map.easeTo(
        mb.CameraOptions(
          center: _pt(pos),
          zoom: _speedKmh > 80 ? 15.5 : (_speedKmh > 50 ? 16.3 : 17),
          pitch: 55,
          bearing: _heading,
          padding: padding,
        ),
        mb.MapAnimationOptions(duration: 900),
      );
    } catch (_) {}
  }

  Future<void> _fitRoute(NavRoute route) async {
    final map = _map;
    if (map == null || route.coordinates.isEmpty) return;
    final padding = _landscape
        ? mb.MbxEdgeInsets(
            top: 40, left: _panelWidth + 40, bottom: 40, right: 80)
        : mb.MbxEdgeInsets(top: 150, left: 50, bottom: 340, right: 50);
    try {
      final points = sample(route.coordinates, 120).map(_pt).toList();
      final camera = await map.cameraForCoordinatesPadding(
        points,
        mb.CameraOptions(pitch: 0, bearing: 0),
        padding,
        16,
        null,
      );
      await map.flyTo(camera, mb.MapAnimationOptions(duration: 1200));
    } catch (_) {
      final dest = _destination;
      if (dest != null) await _flyTo(dest.location, zoom: 13);
    }
  }

  static String _bucket(String c) {
    switch (c) {
      case 'moderate':
      case 'heavy':
      case 'severe':
        return c;
      default:
        return 'low';
    }
  }

  int _congestionColor(String level) {
    switch (level) {
      case 'moderate':
        return 0xFFFFA000;
      case 'heavy':
        return 0xFFE53935;
      case 'severe':
        return 0xFF8B0000;
      default:
        return _night ? 0xFF4FC3F7 : 0xFF1A73E8;
    }
  }

  /// Lukis laluan dengan warna ikut kesesakan trafik.
  Future<void> _drawRoute(NavRoute route) async {
    final manager = _lineManager;
    if (manager == null) return;
    final coords = route.coordinates;
    try {
      await manager.deleteAll();
      if (coords.length < 2) return;

      mb.LineString line(List<LatLng> pts) => mb.LineString(
            coordinates: pts.map((c) => mb.Position(c.lng, c.lat)).toList(),
          );

      final options = <mb.PolylineAnnotationOptions>[
        mb.PolylineAnnotationOptions(
          geometry: line(coords),
          lineColor: _night ? 0xFF01579B : 0xFF0B3D91,
          lineWidth: 12,
        ),
      ];

      final segCount = coords.length - 1;
      String level(int i) =>
          i < route.congestion.length ? _bucket(route.congestion[i]) : 'low';

      var start = 0;
      for (var i = 1; i <= segCount; i++) {
        if (i == segCount || level(i) != level(start)) {
          options.add(mb.PolylineAnnotationOptions(
            geometry: line(coords.sublist(start, i + 1)),
            lineColor: _congestionColor(level(start)),
            lineWidth: 7,
          ));
          start = i;
        }
      }
      await manager.createMulti(options);
    } catch (_) {}
  }

  Future<void> _drawMarkers() async {
    final manager = _markerManager;
    if (manager == null) return;
    try {
      await manager.deleteAll();
      final dest = _destination;
      if (dest != null) {
        await manager.create(mb.CircleAnnotationOptions(
          geometry: _pt(dest.location),
          circleColor: 0xFFE53935,
          circleRadius: 10,
          circleStrokeColor: 0xFFFFFFFF,
          circleStrokeWidth: 3,
        ));
      }
      final stop = _stop;
      if (stop != null) {
        await manager.create(mb.CircleAnnotationOptions(
          geometry: _pt(stop.location),
          circleColor: 0xFFF57C00,
          circleRadius: 9,
          circleStrokeColor: 0xFFFFFFFF,
          circleStrokeWidth: 3,
        ));
      }
    } catch (_) {}
  }

  Future<void> _drawFuelMarkers() async {
    final manager = _fuelManager;
    if (manager == null) return;
    try {
      await manager.deleteAll();
      if (_fuelResults.isEmpty) return;
      await manager.createMulti([
        for (final f in _fuelResults)
          mb.CircleAnnotationOptions(
            geometry: _pt(f.location),
            circleColor: 0xFFFFA000,
            circleRadius: 7,
            circleStrokeColor: 0xFFFFFFFF,
            circleStrokeWidth: 2,
          ),
      ]);
    } catch (_) {}
  }

  // ---------------------------------------------------------------------
  // Carian
  // ---------------------------------------------------------------------

  void _onSearchChanged(String text) {
    _debounce?.cancel();
    final q = text.trim();
    if (q.length < 3) {
      setState(() {
        _results = [];
        _searchMessage = null;
        _searching = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 450), () => _runSearch(q));
  }

  Future<void> _runSearch(String q) async {
    setState(() {
      _searching = true;
      _searchMessage = null;
    });
    try {
      final results = await _api.search(q, near: _myPos);
      if (!mounted || _searchCtrl.text.trim() != q) return;
      setState(() {
        _results = results;
        _searchMessage = results.isEmpty ? 'Tiada hasil untuk "$q".' : null;
      });
    } on MapboxApiException catch (e) {
      if (mounted) setState(() => _searchMessage = e.message);
    } catch (_) {
      if (mounted) setState(() => _searchMessage = 'Carian gagal.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _selectPlace(PlaceResult place) async {
    _searchFocus.unfocus();
    setState(() {
      _searchCtrl.text = place.name;
      _results = [];
      _searchMessage = null;
      _destination = place;
      _stop = null;
      _route = null;
      _arrived = false;
    });
    await _drawMarkers();
    if (_myPos == null) {
      _toast('Menunggu lokasi GPS anda...');
      await _flyTo(place.location, zoom: 14);
      return;
    }
    await _loadRoute();
  }

  // ---------------------------------------------------------------------
  // Stesen minyak
  // ---------------------------------------------------------------------

  Future<void> _findFuel() async {
    final pos = _myPos;
    final route = _route;
    List<LatLng>? ahead;
    if (route != null && route.coordinates.length > 1) {
      final from = (_navigating ? _snapSegment : 0)
          .clamp(0, route.coordinates.length - 2)
          .toInt();
      ahead = route.coordinates.sublist(from);
    }
    if (pos == null && ahead == null) {
      _toast('Menunggu lokasi GPS anda...');
      return;
    }

    _toast(ahead != null
        ? 'Mencari stesen minyak di sepanjang laluan...'
        : 'Mencari stesen minyak berdekatan...');
    try {
      final list = await _api.fuelStations(near: pos, routeAhead: ahead);
      if (!mounted) return;
      if (list.isEmpty) {
        _toast('Tiada stesen minyak dijumpai.');
        return;
      }
      if (pos != null) {
        list.sort((a, b) => distanceBetween(pos, a.location)
            .compareTo(distanceBetween(pos, b.location)));
      }
      setState(() => _fuelResults = list);
      await _drawFuelMarkers();
      await _showFuelSheet(list);
    } on MapboxApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Carian stesen minyak gagal.');
    }
  }

  Future<void> _showFuelSheet(List<PlaceResult> list) async {
    final hasRoute = _route != null && _destination != null;
    final chosen = await showModalBottomSheet<PlaceResult>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) {
        final pos = _myPos;
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(ctx).height * 0.6,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                  child: Text(
                    hasRoute
                        ? 'Stesen minyak — pilih untuk singgah'
                        : 'Stesen minyak berdekatan',
                    style: Theme.of(ctx).textTheme.titleMedium,
                  ),
                ),
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final f = list[i];
                      final subtitle = [
                        if (f.brand != null) f.brand!,
                        if (f.address.isNotEmpty) f.address,
                      ].join(' • ');
                      return ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFFFFE0B2),
                          child: Icon(Icons.local_gas_station,
                              color: Color(0xFFE65100)),
                        ),
                        title: Text(f.name,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(subtitle,
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        trailing: pos == null
                            ? null
                            : Text(formatDistance(
                                distanceBetween(pos, f.location))),
                        onTap: () => Navigator.of(ctx).pop(f),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (!mounted) return;
    setState(() => _fuelResults = []);
    await _drawFuelMarkers();
    if (chosen == null) return;

    if (hasRoute) {
      setState(() => _stop = chosen);
      await _drawMarkers();
      _speechPrefix = 'Singgah di ${chosen.name}.';
      await _loadRoute(fit: !_navigating);
    } else {
      await _selectPlace(chosen);
    }
  }

  Future<void> _removeStop() async {
    setState(() => _stop = null);
    await _drawMarkers();
    await _loadRoute();
  }

  // ---------------------------------------------------------------------
  // Laluan & navigasi
  // ---------------------------------------------------------------------

  Future<void> _loadRoute({bool fit = true}) async {
    final from = _myPos;
    final dest = _destination;
    if (from == null || dest == null) return;
    final stop = _stop;

    setState(() => _loadingRoute = true);
    try {
      final route = await _api.route([
        from,
        if (stop != null) stop.location,
        dest.location,
      ]);
      if (!mounted || _destination != dest) return;
      setState(() {
        _route = route;
        _stepIndex = route.steps.length > 1 ? 1 : 0;
        _remainingDistance = route.distance;
        _remainingDuration = route.duration;
        _distToManeuver =
            route.steps.isNotEmpty ? route.steps.first.distance : 0;
        _offRouteCount = 0;
        _arrived = false;
        _announcedStep = -1;
        _announcedIncidents.clear();
      });
      await _drawRoute(route);
      if (fit) await _fitRoute(route);
      if (_navigating) _updateProgress();
    } on MapboxApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Gagal mendapatkan laluan.');
    } finally {
      if (mounted) setState(() => _loadingRoute = false);
    }
  }

  void _startNavigation() {
    if (_route == null || _myPos == null) return;
    setState(() {
      _navigating = true;
      _followUser = true;
      _arrived = false;
      _announcedStep = -1;
    });
    _speechPrefix = 'Memulakan navigasi.';
    _updateProgress();
    if (_speechPrefix != null) _say('');
    _followCamera();
  }

  Future<void> _stopNavigation() async {
    _voice.stop();
    setState(() {
      _navigating = false;
      _followUser = true;
      _incidentAhead = null;
    });
    final route = _route;
    if (route != null) await _fitRoute(route);
  }

  Future<void> _cancelRoute() async {
    _voice.stop();
    setState(() {
      _navigating = false;
      _arrived = false;
      _route = null;
      _destination = null;
      _stop = null;
      _incidentAhead = null;
      _searchCtrl.clear();
      _results = [];
      _searchMessage = null;
    });
    try {
      await _lineManager?.deleteAll();
    } catch (_) {}
    await _drawMarkers();
    final pos = _myPos;
    if (pos != null) await _flyTo(pos);
  }

  void _arrive() {
    _arrived = true;
    _navigating = false;
    _remainingDistance = 0;
    _remainingDuration = 0;
    _incidentAhead = null;
    _say('Anda telah tiba di destinasi.');
  }

  /// Kemas kini kedudukan dalam laluan, arahan, suara & amaran.
  void _updateProgress() {
    final route = _route;
    final pos = _myPos;
    final dest = _destination;
    if (route == null || pos == null || dest == null) return;
    final steps = route.steps;
    if (steps.isEmpty || route.coordinates.length < 2) return;

    final snap = snapToLine(pos, route.coordinates, route.cumulative);
    _snapSegment = snap.segment;
    final along = snap.along;
    final total = route.geometryLength;
    final scale = total > 0 ? route.distance / total : 1.0;

    // Tiba di destinasi akhir?
    if (distanceBetween(pos, dest.location) < _arrivedMeters ||
        (total - along < 15 && snap.offRoute < 40)) {
      _arrive();
      return;
    }

    // Melepasi hentian (stesen minyak)?
    final stop = _stop;
    if (stop != null && distanceBetween(pos, stop.location) < 40) {
      _stop = null;
      _drawMarkers();
      _say('Anda telah tiba di hentian. Teruskan ke destinasi.');
    }

    // Gerakan seterusnya = langkah pertama yang belum dilepasi.
    var idx = steps.length - 1;
    for (var i = 1; i < steps.length; i++) {
      if (route.stepAlong[i] > along + 3) {
        idx = i;
        break;
      }
    }
    _stepIndex = idx;
    _distToManeuver = math.max(0.0, (route.stepAlong[idx] - along) * scale);
    _remainingDistance = math.max(0.0, (total - along) * scale);

    var time = 0.0;
    for (var k = 0; k < steps.length; k++) {
      final s = route.stepAlong[k];
      final e = k + 1 < steps.length ? route.stepAlong[k + 1] : total;
      if (e <= along) continue;
      final len = e - s;
      final frac = len <= 0
          ? 0.0
          : ((e - math.max(s, along)) / len).clamp(0.0, 1.0).toDouble();
      time += steps[k].duration * frac;
    }
    _remainingDuration = time;

    // Had laju di segmen semasa.
    _limitKmh = snap.segment < route.maxSpeedKmh.length
        ? route.maxSpeedKmh[snap.segment]
        : null;

    // Arahan suara untuk belokan.
    final spoke = _announceManeuver(route, idx);

    // Insiden di hadapan.
    RouteIncident? nearest;
    var nearestDist = double.infinity;
    for (final inc in route.incidents) {
      final d = (route.cumulative[inc.geometryIndex] - along) * scale;
      if (d > -30 && d < 3000 && d < nearestDist) {
        nearest = inc;
        nearestDist = d;
      }
    }
    _incidentAhead = nearest;
    _incidentDist = nearest == null ? 0.0 : math.max(0.0, nearestDist);
    if (!spoke &&
        nearest != null &&
        nearestDist < 1200 &&
        _announcedIncidents.add(nearest.geometryIndex)) {
      final label = incidentLabel(nearest.type).replaceAll(' / ', ' atau ');
      _say('Awas, ${lowerFirst(label)} di hadapan, '
          '${spokenDistance(math.max(50.0, nearestDist))}.');
    }

    // Terkeluar laluan? Kira semula.
    final limit = math.max(_offRouteMeters, _accuracy * 1.5);
    _offRouteCount = snap.offRoute > limit ? _offRouteCount + 1 : 0;
    if (_offRouteCount >= _offRouteHits &&
        !_loadingRoute &&
        DateTime.now().difference(_lastReroute) > _rerouteCooldown) {
      _lastReroute = DateTime.now();
      _offRouteCount = 0;
      _say('Mengira semula laluan.');
      _loadRoute(fit: false);
    }
  }

  /// Sebut arahan belokan pada jarak yang sesuai. Pulang true jika bercakap.
  bool _announceManeuver(NavRoute route, int idx) {
    final steps = route.steps;
    final step = steps[idx];
    final highway = _speedKmh > 60;
    final far = highway ? 1000.0 : 400.0;
    final near = highway ? 300.0 : 90.0;
    final d = _distToManeuver;

    if (idx != _announcedStep) {
      _announcedStep = idx;
      _saidFar = false;
      _saidNear = false;
      if (d > far + 600 && step.type != 'arrive') {
        _say('Ikut jalan ini sejauh ${spokenDistance(d)}.');
        return true;
      }
    }

    if (!_saidNear && d <= near) {
      _saidNear = true;
      _saidFar = true;
      var text = d < 25
          ? instructionFor(step)
          : spokenAhead(step, math.max(10.0, d));
      if (idx + 1 < steps.length &&
          route.stepAlong[idx + 1] - route.stepAlong[idx] < 150) {
        text += ', kemudian ${lowerFirst(instructionFor(steps[idx + 1]))}';
      }
      _say('$text.');
      return true;
    }

    if (!_saidFar && d <= far && d > near * 1.5) {
      _saidFar = true;
      _say('${spokenAhead(step, d)}.');
      return true;
    }
    return false;
  }

  void _toggleVoice() {
    setState(() => _voiceOn = !_voiceOn);
    _voice.enabled = _voiceOn;
    if (!_voiceOn) _voice.stop();
    _toast(_voiceOn ? 'Suara dihidupkan' : 'Suara disenyapkan');
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ));
  }

  // ---------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    _screen = size;
    _landscape = size.width > size.height;
    _panelWidth = _landscape ? math.min(400.0, size.width * 0.42) : 0.0;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Positioned.fill(child: _mapView),
          if (_landscape) ..._buildLandscape() else ..._buildPortrait(),
        ],
      ),
    );
  }

  /// Peta dibina sekali sahaja supaya kamera tidak ditetapkan semula
  /// setiap kali skrin dikemas kini.
  late final Widget _mapView = Listener(
      behavior: HitTestBehavior.translucent,
      onPointerMove: (_) {
        if (_navigating && _followUser) {
          setState(() => _followUser = false);
        }
      },
      child: mb.MapWidget(
        styleUri: _initialStyle,
        viewport: mb.CameraViewportState(
          center: _pt(const LatLng(kDefaultLat, kDefaultLng)),
          zoom: 12,
        ),
        onMapCreated: _onMapCreated,
        onStyleLoadedListener: (_) => _onStyleLoaded(),
      ),
    );

  /// Telefon menegak: arahan di atas, ringkasan di bawah.
  List<Widget> _buildPortrait() {
    return [
      Positioned(
        top: 0,
        left: 0,
        right: 0,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: _buildTopContent(),
          ),
        ),
      ),
      Positioned(
        left: 12,
        right: 12,
        bottom: 12,
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildMapControls(),
              const SizedBox(height: 10),
              _buildBottomContent(),
            ],
          ),
        ),
      ),
    ];
  }

  /// Telefon melintang: semua maklumat dalam satu panel di kiri,
  /// peta kekal jelas di kanan.
  List<Widget> _buildLandscape() {
    return [
      Positioned(
        top: 0,
        bottom: 0,
        left: 0,
        width: _panelWidth,
        child: SafeArea(
          right: false,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(10, 8, 6, 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildTopContent(),
                const SizedBox(height: 8),
                _buildBottomContent(),
              ],
            ),
          ),
        ),
      ),
      Positioned(
        right: 12,
        bottom: 12,
        left: _panelWidth + 12,
        child: SafeArea(left: false, top: false, child: _buildMapControls()),
      ),
    ];
  }

  Widget _buildTopContent() {
    final route = _route;
    if (_navigating && route != null && route.steps.isNotEmpty) {
      final step = route.steps[_stepIndex];
      NavStep? next;
      if (_stepIndex + 1 < route.steps.length &&
          route.stepAlong[_stepIndex + 1] - route.stepAlong[_stepIndex] <
              300) {
        next = route.steps[_stepIndex + 1];
      }
      final incident = _incidentAhead;
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InstructionCard(step: step, distance: _distToManeuver, next: next),
          if (incident != null) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: IncidentPill(
                incident: incident,
                distanceAhead: _incidentDist,
              ),
            ),
          ],
        ],
      );
    }
    return _buildSearch();
  }

  Widget _buildBottomContent() {
    if (_arrived) {
      return PanelCard(
        child: Row(
          children: [
            const Icon(Icons.flag, color: kNavGreen, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Anda telah tiba di ${_destination?.name ?? 'destinasi'}',
                style: const TextStyle(fontSize: 17),
              ),
            ),
            FilledButton(
                onPressed: _cancelRoute, child: const Text('Selesai')),
          ],
        ),
      );
    }

    final route = _route;
    if (route == null) {
      if (!_loadingRoute) return const SizedBox.shrink();
      return const PanelCard(
        child: Row(
          children: [
            SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
            SizedBox(width: 14),
            Text('Mengira laluan...', style: TextStyle(fontSize: 16)),
          ],
        ),
      );
    }

    if (_navigating) {
      return TripBar(
        remainingDuration: _remainingDuration,
        remainingDistance: _remainingDistance,
        trafficDelay: route.trafficDelay,
        voiceOn: _voiceOn,
        onToggleVoice: _toggleVoice,
        onFuel: _findFuel,
        onEnd: _stopNavigation,
      );
    }

    return RoutePreviewCard(
      route: route,
      destinationName: _destination?.name ?? 'Destinasi',
      stopName: _stop?.name,
      onRemoveStop: _stop == null ? null : _removeStop,
      remainingDuration: _remainingDuration,
      remainingDistance: _remainingDistance,
      loading: _loadingRoute,
      onStart: _myPos == null ? null : _startNavigation,
      onCancel: _cancelRoute,
      onFuel: _findFuel,
    );
  }

  /// Laju (kiri) dan butang peta (kanan).
  Widget _buildMapControls() {
    final recenter = _navigating && !_followUser;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        if (_navigating)
          SpeedBadge(speedKmh: _speedKmh, limitKmh: _limitKmh),
        const Spacer(),
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            MapRoundButton(
              tooltip: 'Tema siang/malam',
              icon: switch (_themePref) {
                ThemePref.auto => Icons.brightness_auto,
                ThemePref.day => Icons.light_mode,
                ThemePref.night => Icons.dark_mode,
              },
              onPressed: _cycleTheme,
            ),
            const SizedBox(height: 10),
            MapRoundButton(
              tooltip: recenter ? 'Pusat semula' : 'Lokasi saya',
              icon: recenter ? Icons.navigation : Icons.my_location,
              active: recenter,
              onPressed: _onLocatePressed,
            ),
          ],
        ),
      ],
    );
  }

  void _onLocatePressed() {
    final pos = _myPos;
    if (pos == null) {
      if (!_locationReady) {
        _initLocation();
      } else {
        _toast('Menunggu lokasi GPS...');
      }
      return;
    }
    if (_navigating) {
      setState(() => _followUser = true);
      _followCamera();
    } else {
      _flyTo(pos, zoom: 16);
    }
  }

  Widget _buildSearch() {
    final scheme = Theme.of(context).colorScheme;
    final showFuelChip = _searchCtrl.text.isEmpty && _route == null;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Material(
          elevation: 6,
          color: scheme.surface,
          borderRadius: BorderRadius.circular(28),
          child: TextField(
            controller: _searchCtrl,
            focusNode: _searchFocus,
            onChanged: _onSearchChanged,
            textInputAction: TextInputAction.search,
            onSubmitted: (q) {
              if (q.trim().length >= 2) _runSearch(q.trim());
            },
            style: TextStyle(color: scheme.onSurface, fontSize: 16),
            decoration: InputDecoration(
              hintText: 'Cari destinasi (cth: KLCC, Mid Valley)',
              hintStyle: TextStyle(color: scheme.onSurfaceVariant),
              prefixIcon: Icon(Icons.search, color: scheme.primary),
              suffixIcon: _searching
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : (_searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: _cancelRoute,
                        )
                      : null),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
        if (showFuelChip)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: ActionChip(
                elevation: 3,
                backgroundColor: scheme.surface,
                avatar: const Icon(Icons.local_gas_station,
                    color: Color(0xFFF57C00)),
                label: const Text('Stesen minyak berdekatan'),
                onPressed: _findFuel,
              ),
            ),
          ),
        if (_results.isNotEmpty || _searchMessage != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: PanelCard(
              padding: EdgeInsets.zero,
              child: _searchMessage != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(_searchMessage!),
                    )
                  : ConstrainedBox(
                      constraints: BoxConstraints(
                        maxHeight: _landscape ? 220 : 320,
                      ),
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemCount: _results.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final r = _results[i];
                          final pos = _myPos;
                          return ListTile(
                            leading: Icon(Icons.place, color: scheme.primary),
                            title: Text(
                              r.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              r.address,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: pos == null
                                ? null
                                : Text(
                                    formatDistance(
                                        distanceBetween(pos, r.location)),
                                    style: TextStyle(
                                      color: scheme.onSurfaceVariant,
                                      fontSize: 12,
                                    ),
                                  ),
                            onTap: () => _selectPlace(r),
                          );
                        },
                      ),
                    ),
            ),
          ),
      ],
    );
  }
}
